from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any
import asyncio
import random

app = FastAPI(title="KumbhSahayak API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class IncidentCreate(BaseModel):
    latitude: float
    longitude: float
    note: str | None = None


class ServiceItem(BaseModel):
    id: int
    name: str
    category: str
    phone: str | None = None
    latitude: float
    longitude: float


# In-memory stores for prototype
INCIDENTS: Dict[int, Dict[str, Any]] = {}
SERVICES: List[ServiceItem] = [
    ServiceItem(id=1, name="City Hospital", category="medical", phone="100", latitude=25.4358, longitude=81.8463),
    ServiceItem(id=2, name="Fire Station", category="fire", phone="101", latitude=25.4365, longitude=81.8441),
    ServiceItem(id=3, name="Hotel Ganga", category="hotel", phone="+91-9999999999", latitude=25.4382, longitude=81.8488),
]


@app.get("/")
async def root():
    return {"status": "ok", "name": "KumbhSahayak"}


@app.get("/services", response_model=List[ServiceItem])
async def list_services(category: str | None = None):
    if category:
        return [s for s in SERVICES if s.category == category]
    return SERVICES


class CrowdClient:
    def __init__(self, websocket: WebSocket):
        self.websocket = websocket


class CrowdHub:
    def __init__(self):
        self.clients: List[CrowdClient] = []
        self.running = False

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        client = CrowdClient(websocket)
        self.clients.append(client)
        if not self.running:
            self.running = True
            asyncio.create_task(self._broadcast_loop())

    async def disconnect(self, websocket: WebSocket):
        self.clients = [c for c in self.clients if c.websocket is not websocket]
        if not self.clients:
            self.running = False

    async def _broadcast_loop(self):
        # Simulate N people moving in M areas (simple dots in a 2D box [0,1]x[0,1])
        num_people = 150
        positions = [[random.random(), random.random()] for _ in range(num_people)]
        velocities = [[(random.random()-0.5)*0.01, (random.random()-0.5)*0.01] for _ in range(num_people)]
        while self.running:
            # update positions
            for i in range(num_people):
                positions[i][0] += velocities[i][0]
                positions[i][1] += velocities[i][1]
                # bounce on walls
                for axis in (0, 1):
                    if positions[i][axis] < 0:
                        positions[i][axis] = 0
                        velocities[i][axis] *= -1
                    elif positions[i][axis] > 1:
                        positions[i][axis] = 1
                        velocities[i][axis] *= -1

            payload = {"type": "crowd", "people": positions}
            # send to all clients
            to_remove: List[CrowdClient] = []
            for client in self.clients:
                try:
                    await client.websocket.send_json(payload)
                except Exception:
                    to_remove.append(client)
            if to_remove:
                for c in to_remove:
                    try:
                        await c.websocket.close()
                    except Exception:
                        pass
                    self.clients.remove(c)
                if not self.clients:
                    self.running = False
                    break

            await asyncio.sleep(0.05)  # 20 FPS


crowd_hub = CrowdHub()


@app.websocket("/ws/crowd")
async def websocket_endpoint(websocket: WebSocket):
    try:
        await crowd_hub.connect(websocket)
        while True:
            # Keep connection alive; optionally receive pings
            await websocket.receive_text()
    except WebSocketDisconnect:
        await crowd_hub.disconnect(websocket)


@app.post("/incidents")
async def create_incident(payload: IncidentCreate):
    incident_id = len(INCIDENTS) + 1
    incident = {
        "id": incident_id,
        "latitude": payload.latitude,
        "longitude": payload.longitude,
        "note": payload.note,
        "status": "created",
    }
    INCIDENTS[incident_id] = incident
    return incident


@app.get("/incidents")
async def list_incidents():
    return list(INCIDENTS.values())


class IncidentStatusUpdate(BaseModel):
    status: str  # e.g., acknowledged | en_route | on_site | resolved
    volunteer_id: int | None = None


@app.post("/incidents/{incident_id}/status")
async def update_incident_status(incident_id: int, payload: IncidentStatusUpdate):
    incident = INCIDENTS.get(incident_id)
    if not incident:
        return {"error": "not_found", "message": "Incident not found"}
    incident["status"] = payload.status
    if payload.volunteer_id is not None:
        incident["volunteer_id"] = payload.volunteer_id
    return incident


