const API_BASE = 'http://localhost:8000';
const langSel = document.getElementById('lang');

const I18N = {
  en: {
    app_title: 'KumbhSahayak',
    tab_crowd: 'Crowd', tab_services: 'Services', tab_sos: 'SOS',
    crowd_title: 'Live Crowd Simulation', crowd_hint: 'Prototype visualization of moving people (dots).',
    mode_dots: 'Dots', mode_heat: 'Heatmap', low: 'Low', high: 'High',
    services_title: 'Nearby Services', category_label: 'Category:', cat_medical: 'Medical', cat_fire: 'Fire', cat_hotel: 'Hotel', refresh: 'Refresh',
    sos_title: 'Emergency SOS', sos_desc: 'Share your current location with volunteers.', sos_placeholder: 'Describe your emergency (optional)', send_sos: 'Send SOS',
    footer_note: 'Prototype MVP • Backend at http://localhost:8000',
    geoloc_request: 'Requesting location...', geoloc_not_supported: 'Geolocation not supported.', sending_sos: 'Sending SOS...', sos_created: 'SOS created: ', sos_failed: 'Failed to send SOS: ', loc_error: 'Location error: '
  },
  hi: {
    app_title: 'कुम्भसहायक',
    tab_crowd: 'भीड़', tab_services: 'सेवाएँ', tab_sos: 'आपातकाल',
    crowd_title: 'लाइव भीड़ सिमुलेशन', crowd_hint: 'गतिमान बिंदुओं द्वारा भीड़ का प्रदर्शन।',
    mode_dots: 'बिंदु', mode_heat: 'हीटमैप', low: 'कम', high: 'ज्यादा',
    services_title: 'नज़दीकी सेवाएँ', category_label: 'श्रेणी:', cat_medical: 'चिकित्सा', cat_fire: 'दमकल', cat_hotel: 'होटल', refresh: 'रिफ्रेश',
    sos_title: 'आपातकालीन SOS', sos_desc: 'अपना स्थान स्वयंसेवकों के साथ साझा करें।', sos_placeholder: 'अपनी आपात स्थिति का वर्णन करें (वैकल्पिक)', send_sos: 'SOS भेजें',
    footer_note: 'प्रोटोटाइप एमवीपी • बैकएंड http://localhost:8000',
    geoloc_request: 'स्थान प्राप्त किया जा रहा है...', geoloc_not_supported: 'जियोलोकेशन समर्थित नहीं है।', sending_sos: 'SOS भेजा जा रहा है...', sos_created: 'SOS बनाया गया: ', sos_failed: 'SOS भेजने में विफल: ', loc_error: 'स्थान त्रुटि: '
  },
  mr: {
    app_title: 'कुंभसहायक',
    tab_crowd: 'गर्दी', tab_services: 'सेवा', tab_sos: 'आपत्कालीन',
    crowd_title: 'थेट गर्दी सिम्युलेशन', crowd_hint: 'हलत्या बिंदूंनी गर्दीचे दृश्य.',
    mode_dots: 'बिंदू', mode_heat: 'हिटमॅप', low: 'कमी', high: 'जास्त',
    services_title: 'जवळच्या सेवा', category_label: 'वर्ग:', cat_medical: 'वैद्यकीय', cat_fire: 'अग्निशमन', cat_hotel: 'हॉटेल', refresh: 'रीफ्रेश',
    sos_title: 'आपत्कालीन SOS', sos_desc: 'तुमचे स्थान स्वयंसेवकांसोबत शेअर करा.', sos_placeholder: 'आपत्कालीन माहिती (ऐच्छिक)', send_sos: 'SOS पाठवा',
    footer_note: 'प्रोटोटाइप एमव्हीपी • बॅकएंड http://localhost:8000',
    geoloc_request: 'स्थान घेत आहे...', geoloc_not_supported: 'भौगोलिक स्थान समर्थित नाही.', sending_sos: 'SOS पाठवत आहे...', sos_created: 'SOS तयार: ', sos_failed: 'SOS पाठवण्यात अयशस्वी: ', loc_error: 'स्थान त्रुटी: '
  }
};

function applyI18n() {
  const dict = I18N[langSel?.value || 'en'] || I18N.en;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.textContent = dict[key];
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (dict[key]) el.setAttribute('placeholder', dict[key]);
  });
}
if (langSel) {
  langSel.addEventListener('change', applyI18n);
  applyI18n();
}

// Tabs
const tabCrowd = document.getElementById('tab-crowd');
const tabServices = document.getElementById('tab-services');
const tabSos = document.getElementById('tab-sos');
const viewCrowd = document.getElementById('view-crowd');
const viewServices = document.getElementById('view-services');
const viewSos = document.getElementById('view-sos');

function setActive(view) {
  [viewCrowd, viewServices, viewSos].forEach(v => v.classList.remove('active'));
  [tabCrowd, tabServices, tabSos].forEach(t => t.classList.remove('active'));
  if (view === 'crowd') { viewCrowd.classList.add('active'); tabCrowd.classList.add('active'); }
  if (view === 'services') { viewServices.classList.add('active'); tabServices.classList.add('active'); }
  if (view === 'sos') { viewSos.classList.add('active'); tabSos.classList.add('active'); }
}

tabCrowd.addEventListener('click', () => setActive('crowd'));
tabServices.addEventListener('click', () => setActive('services'));
tabSos.addEventListener('click', () => setActive('sos'));

// Crowd canvas + WebSocket
const canvas = document.getElementById('crowd-canvas');
const ctx = canvas.getContext('2d');
let people = [];
let mode = 'dots';
const btnDots = document.getElementById('mode-dots');
const btnMapDots = document.getElementById('mode-mapdots');
const btnHeat = document.getElementById('mode-heat');
const mapDiv = document.getElementById('crowd-map');
let map = null;
let heat = null;
const legend = document.getElementById('heat-legend');
let mapCanvas = null;

// Fallback client-side simulation if WS not available
let fallbackPeople = null;
let fallbackVelocity = null;
let lastWsUpdateMs = 0;
function ensureFallbackInit(count = 150) {
  if (!fallbackPeople) {
    fallbackPeople = Array.from({ length: count }, () => [Math.random(), Math.random()]);
    fallbackVelocity = Array.from({ length: count }, () => [(Math.random() - 0.5) * 0.01, (Math.random() - 0.5) * 0.01]);
  }
}
function stepFallback() {
  if (!fallbackPeople || !fallbackVelocity) return;
  for (let i = 0; i < fallbackPeople.length; i++) {
    fallbackPeople[i][0] += fallbackVelocity[i][0];
    fallbackPeople[i][1] += fallbackVelocity[i][1];
    for (let a = 0; a < 2; a++) {
      if (fallbackPeople[i][a] < 0) { fallbackPeople[i][a] = 0; fallbackVelocity[i][a] *= -1; }
      if (fallbackPeople[i][a] > 1) { fallbackPeople[i][a] = 1; fallbackVelocity[i][a] *= -1; }
    }
  }
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (mode === 'dots') {
    ctx.fillStyle = '#0ea5e9';
    let pts = people;
    // If no WS updates recently, run fallback simulation
    if (Date.now() - lastWsUpdateMs > 1500) {
      ensureFallbackInit(150);
      stepFallback();
      pts = fallbackPeople;
    }
    for (const p of pts) {
      const x = p[0] * canvas.width;
      const y = p[1] * canvas.height;
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  if (mode === 'mapdots' && map && mapCanvas) {
    const mctx = mapCanvas.getContext('2d');
    const size = map.getSize();
    mapCanvas.width = size.x; mapCanvas.height = size.y;
    mctx.clearRect(0, 0, mapCanvas.width, mapCanvas.height);
    mctx.fillStyle = 'rgba(14,165,233,0.9)';
    const base = { lat: 25.44, lng: 81.85 };
    const scaleKm = 2.0;
    const kmPerDegLat = 110.574;
    const kmPerDegLng = 111.320 * Math.cos(base.lat * Math.PI/180);
    let pts = people;
    if (Date.now() - lastWsUpdateMs > 1500) { ensureFallbackInit(150); stepFallback(); pts = fallbackPeople; }
    for (const p of pts) {
      const dxKm = (p[0] - 0.5) * scaleKm;
      const dyKm = (p[1] - 0.5) * scaleKm;
      const lat = base.lat + (dyKm / kmPerDegLat);
      const lng = base.lng + (dxKm / kmPerDegLng);
      const pt = map.latLngToContainerPoint([lat, lng]);
      mctx.beginPath();
      mctx.arc(pt.x, pt.y, 3, 0, Math.PI*2);
      mctx.fill();
    }
  }
  requestAnimationFrame(render);
}
render();

function connectCrowdWS() {
  const ws = new WebSocket('ws://localhost:8000/ws/crowd');
  ws.onopen = () => {
    // Keep alive pings
    setInterval(() => { try { ws.send('ping'); } catch (e) {} }, 15000);
  };
  ws.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data);
      if (data.type === 'crowd') {
        people = data.people;
        lastWsUpdateMs = Date.now();
        if (mode === 'heat' && map && heat) {
          // Map normalized [0..1] positions to lat/lng around Prayagraj area (approx 25.44, 81.85)
          const base = { lat: 25.44, lng: 81.85 };
          const scaleKm = 2.0; // roughly a few km square
          const kmPerDegLat = 110.574;
          const kmPerDegLng = 111.320 * Math.cos(base.lat * Math.PI/180);
          const pts = people.map(p => {
            const dxKm = (p[0] - 0.5) * scaleKm;
            const dyKm = (p[1] - 0.5) * scaleKm;
            const lat = base.lat + (dyKm / kmPerDegLat);
            const lng = base.lng + (dxKm / kmPerDegLng);
            return [lat, lng, 0.6];
          });
          heat.setLatLngs(pts);
        }
      }
    } catch {}
  };
  ws.onclose = () => {
    setTimeout(connectCrowdWS, 2000);
  };
}
connectCrowdWS();

function initMap() {
  if (map) return;
  map = L.map('crowd-map').setView([25.44, 81.85], 14);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);
  heat = L.heatLayer([], { radius: 25, blur: 15, maxZoom: 17 }).addTo(map);
  map.whenReady(() => {
    mapCanvas = document.createElement('canvas');
    mapCanvas.className = 'map-canvas';
    map.getPanes().overlayPane.appendChild(mapCanvas);
    map.on('move zoom resize', () => { /* redraw in render() */ });
  });
}

btnDots?.addEventListener('click', () => {
  mode = 'dots';
  btnDots.classList.add('active');
  btnHeat.classList.remove('active');
  canvas.style.display = 'block';
  mapDiv.style.display = 'none';
  if (legend) legend.style.display = 'none';
});

btnHeat?.addEventListener('click', () => {
  mode = 'heat';
  btnHeat.classList.add('active');
  btnDots.classList.remove('active');
  btnMapDots?.classList.remove('active');
  canvas.style.display = 'none';
  mapDiv.style.display = 'block';
  initMap();
  if (legend) legend.style.display = 'flex';
});

btnMapDots?.addEventListener('click', () => {
  mode = 'mapdots';
  btnMapDots.classList.add('active');
  btnDots.classList.remove('active');
  btnHeat.classList.remove('active');
  canvas.style.display = 'none';
  mapDiv.style.display = 'block';
  initMap();
  if (legend) legend.style.display = 'none';
});

// Services list
const listEl = document.getElementById('services-list');
const categoryEl = document.getElementById('service-category');
const refreshBtn = document.getElementById('refresh-services');

async function loadServices() {
  const params = new URLSearchParams();
  if (categoryEl.value) params.set('category', categoryEl.value);
  const res = await fetch(`${API_BASE}/services?${params.toString()}`);
  const items = await res.json();
  listEl.innerHTML = '';
  items.forEach(s => {
    const li = document.createElement('li');
    li.innerHTML = `<div><strong>${s.name}</strong> <small>(${s.category})</small><br/><span>${s.phone ?? ''}</span></div>`;
    const callBtn = document.createElement('a');
    if (s.phone) { callBtn.href = `tel:${s.phone}`; callBtn.textContent = 'Call'; }
    else { callBtn.textContent = 'N/A'; callBtn.style.opacity = '0.5'; }
    li.appendChild(callBtn);
    listEl.appendChild(li);
  });
}

refreshBtn.addEventListener('click', loadServices);
categoryEl.addEventListener('change', loadServices);
loadServices();

// SOS
const sosBtn = document.getElementById('send-sos');
const sosNote = document.getElementById('sos-note');
const sosResult = document.getElementById('sos-result');
const voiceStart = document.getElementById('voice-start');
const voiceStop = document.getElementById('voice-stop');

sosBtn.addEventListener('click', async () => {
  const D = I18N[langSel?.value || 'en'] || I18N.en;
  sosResult.textContent = D.geoloc_request;
  if (!navigator.geolocation) {
    sosResult.textContent = D.geoloc_not_supported;
    return;
  }
  navigator.geolocation.getCurrentPosition(async pos => {
    const { latitude, longitude } = pos.coords;
    sosResult.textContent = D.sending_sos;
    try {
      const res = await fetch(`${API_BASE}/incidents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude, longitude, note: sosNote.value || null })
      });
      const data = await res.json();
      sosResult.textContent = D.sos_created + JSON.stringify(data, null, 2);
    } catch (e) {
      sosResult.textContent = D.sos_failed + e.message;
    }
  }, err => {
    const D2 = I18N[langSel?.value || 'en'] || I18N.en;
    sosResult.textContent = D2.loc_error + err.message;
  }, { enableHighAccuracy: true, timeout: 10000 });
});

// Voice: basic ASR (SpeechRecognition) and TTS (speechSynthesis)
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognizer = null;
if (SR) {
  recognizer = new SR();
  recognizer.lang = (langSel?.value === 'hi') ? 'hi-IN' : (langSel?.value === 'mr') ? 'mr-IN' : 'en-IN';
  recognizer.interimResults = false;
  recognizer.maxAlternatives = 1;
  langSel?.addEventListener('change', () => {
    if (recognizer) recognizer.lang = (langSel.value === 'hi') ? 'hi-IN' : (langSel.value === 'mr') ? 'mr-IN' : 'en-IN';
  });
}

function speak(text) {
  const utter = new SpeechSynthesisUtterance(text);
  const l = langSel?.value || 'en';
  utter.lang = l === 'hi' ? 'hi-IN' : l === 'mr' ? 'mr-IN' : 'en-IN';
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utter);
}

if (voiceStart && recognizer) {
  voiceStart.addEventListener('click', () => {
    try { recognizer.start(); } catch {}
  });
}
if (voiceStop && recognizer) {
  voiceStop.addEventListener('click', () => {
    try { recognizer.stop(); } catch {}
  });
}

if (recognizer) {
  recognizer.onresult = (e) => {
    const transcript = e.results[0][0].transcript;
    sosNote.value = transcript;
    const D = I18N[langSel?.value || 'en'] || I18N.en;
    speak(D.sending_sos);
    sosBtn.click();
  };
  recognizer.onerror = (e) => {
    // ignore
  };
}


